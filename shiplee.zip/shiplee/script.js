// Scroll-to-Top Button Functionality
const scrollTopButton = document.getElementById('scroll-to-top');

// Show the button when scrolled down more than 200px
window.addEventListener('scroll', () => {
    if (window.scrollY > 200) {
        scrollTopButton.style.display = 'block'; // Show the button
    } else {
        scrollTopButton.style.display = 'none'; // Hide the button when scrolled to the top
    }
});

// Smooth scroll to the top when the button is clicked
scrollTopButton.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});


// Dark Mode Toggle Functionality
const darkModeToggle = document.createElement('button');
darkModeToggle.textContent = 'Toggle Dark Mode';
darkModeToggle.style.position = 'fixed';
darkModeToggle.style.bottom = '60px';
darkModeToggle.style.right = '20px';
darkModeToggle.style.padding = '10px';
darkModeToggle.style.backgroundColor = '#3a7bd5';
darkModeToggle.style.color = '#fff';
darkModeToggle.style.border = 'none';
darkModeToggle.style.borderRadius = '5px';
darkModeToggle.style.cursor = 'pointer';

document.body.appendChild(darkModeToggle);

darkModeToggle.addEventListener('click', () => {
    // Toggle the dark-mode class on the body element
    document.body.classList.toggle('dark-mode');
});

// Lazy Loading for Images (Optional)
const images = document.querySelectorAll('img.lazy-load');
images.forEach(image => {
    image.setAttribute('src', image.getAttribute('data-src'));
    image.removeAttribute('data-src');
});

// Dark Mode Styling in CSS
const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = `
    .dark-mode {
        background-color: #121212;
        color: #ffffff;
    }

    .dark-mode .hero-section {
        background-image: url('image1-dark.jpg'); /* Optional dark version of the hero image */
    }

    .dark-mode .cta-button {
        background: linear-gradient(90deg, #444, #888);
        color: white; /* Change button text color */
    }

    .dark-mode h1, .dark-mode h2, .dark-mode h3, .dark-mode p {
        color: #ffffff; /* Change text color in headings and paragraphs */
    }
`;
document.head.appendChild(styleSheet);
